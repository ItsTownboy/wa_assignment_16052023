﻿using MongoDB.Driver;
using System.Threading.Tasks;
using WEB_API_15052024.Model;

namespace WEB_API_15052024.Services
{
    public class MongoDbService : IMongoDbService
    {
        private readonly IMongoDatabase _database;

        public MongoDbService(IMongoClient mongoClient)
        {
            _database = mongoClient.GetDatabase("codeRowerAssignment"); 
        }

        public async Task<Configuration> GetConfiguration(string configId)
        {
            try
            {
                var collection = _database.GetCollection<Configuration>("configurations"); 
                var filter = Builders<Configuration>.Filter.Eq(c => c.ConfigId, configId);
                var configuration = await collection.Find(filter).FirstOrDefaultAsync();
                return configuration;
            }
            catch (MongoException ex)
            {
               
                Console.WriteLine($"Error retrieving configuration: {ex.Message}");
                throw; 
            }
        }

        public async Task UpdateRemark(string configId, string remark)
        {
            try
            {
                var collection = _database.GetCollection<Configuration>("configurations");
                var filter = Builders<Configuration>.Filter.Eq(c => c.ConfigId, configId);
                var update = Builders<Configuration>.Update.Set(c => c.Remark, remark);
                await collection.UpdateOneAsync(filter, update);
            }
            catch (MongoException ex)
            {
                
                Console.WriteLine($"Error updating remark: {ex.Message}");
                throw; 
            }
        }
    }

   
}
