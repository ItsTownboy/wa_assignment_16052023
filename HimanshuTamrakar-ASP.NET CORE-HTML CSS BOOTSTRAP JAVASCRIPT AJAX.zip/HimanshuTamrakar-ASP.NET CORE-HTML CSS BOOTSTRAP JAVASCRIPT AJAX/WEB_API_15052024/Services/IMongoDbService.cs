﻿using WEB_API_15052024.Model;

namespace WEB_API_15052024.Services
{
    public interface IMongoDbService
    {
        Task<Configuration> GetConfiguration(string configId);
        Task UpdateRemark(string configId, string remark);
    }

}
