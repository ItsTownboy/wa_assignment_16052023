﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.Collections.Generic;

namespace WEB_API_15052024.Model
{
    public class Configuration
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("configId")]
        public string ConfigId { get; set; }

        [BsonElement("data")]
        public List<List<string>> Data { get; set; }

        [BsonElement("remark")]
        public string Remark { get; set; }

        [BsonIgnoreIfNull]
        [BsonElement("__v")]
        public int Version { get; set; }
    }
}
