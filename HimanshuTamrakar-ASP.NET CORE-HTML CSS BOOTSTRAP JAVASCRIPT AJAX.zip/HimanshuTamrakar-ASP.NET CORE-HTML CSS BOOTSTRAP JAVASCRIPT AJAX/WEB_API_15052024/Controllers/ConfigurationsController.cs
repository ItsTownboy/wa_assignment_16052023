﻿using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;
using WEB_API_15052024.Model;
using WEB_API_15052024.Services;

namespace WEB_API_15052024.Controllers
{
    [ApiController]
    [Route("api/configurations")]
    public class ConfigurationsController : ControllerBase
    {
        private readonly IMongoDbService _mongoService;

        public ConfigurationsController(IMongoDbService mongoService)
        {
            _mongoService = mongoService;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetInitialData(string id)
        {
            var config = await _mongoService.GetConfiguration(id);
            if (config == null)
            {
                return NotFound(new { message = $"Configuration with ID {id} not found" });
            }

            var data = config.Data.Take(3).Select(row => row.Take(3).ToArray()).ToArray();
            return Ok(data);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateRemark(string id, [FromBody] RemarkUpdateRequest request)
        {
            var config = await _mongoService.GetConfiguration(id);
            if (config == null)
            {
                return NotFound(new { message = $"Configuration with ID {id} not found" });
            }

            await _mongoService.UpdateRemark(id, request.Remark);
            return Ok(new { message = "success" });
        }
    }

    public class RemarkUpdateRequest
    {
        public string Remark { get; set; }
    }
}
